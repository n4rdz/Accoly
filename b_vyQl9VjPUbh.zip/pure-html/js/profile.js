// ============================================
// PROFILE LOGIC
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    const user = Storage.getCurrentUser();
    if (!user) {
        window.location.href = 'login.html';
        return;
    }

    loadProfile();
});

function loadProfile() {
    const user = Storage.getCurrentUser();
    const stats = Storage.getUserStats(user.id);

    // Set user info
    const initials = user.fullName.split(' ').map(n => n[0]).join('').toUpperCase();
    document.getElementById('profileAvatar').textContent = initials;
    document.getElementById('profileName').textContent = user.fullName;
    document.getElementById('profileStudentId').textContent = user.studentId;

    // Calculate level and progress
    const levelName = Storage.getLevelName(stats.level);
    const levelEmojis = {
        1: '📚',
        2: '📊',
        3: '🔍',
        4: '✓',
        5: '👑'
    };

    document.getElementById('profileLevel').textContent = `Level: ${levelName}`;
    document.getElementById('profileCurrentLevel').textContent = levelName;
    document.getElementById('profileLevelEmoji').textContent = levelEmojis[stats.level] || '📚';

    // Calculate progress to next level
    const levelThresholds = {
        1: 500,
        2: 1500,
        3: 3500,
        4: 7000,
        5: 10000
    };

    const currentThreshold = levelThresholds[stats.level] || 0;
    const nextThreshold = levelThresholds[stats.level + 1] || 10000;
    const currentXP = stats.totalXP;
    const xpInCurrentLevel = currentXP - currentThreshold;
    const xpNeededForLevel = nextThreshold - currentThreshold;
    const progressPercent = Math.min(100, Math.round((xpInCurrentLevel / xpNeededForLevel) * 100));

    document.getElementById('profileProgressPercent').textContent = progressPercent + '%';
    document.getElementById('profileProgressBar').style.width = progressPercent + '%';
    document.getElementById('profileXPProgress').textContent = `${xpInCurrentLevel} / ${xpNeededForLevel} XP`;

    // Update stats
    document.getElementById('profileAccuracy').textContent = stats.accuracyPercentage + '%';
    document.getElementById('profileQuizzes').textContent = stats.totalQuizzes;
    document.getElementById('profileXP').textContent = stats.totalXP;
    document.getElementById('profileStreak').textContent = (stats.currentStreak || 0) + 'd';

    // Load recent quizzes
    loadRecentQuizzes(user.id);
}

function loadRecentQuizzes(userId) {
    const attempts = Storage.getQuizAttempts(userId);
    const recentContainer = document.getElementById('recentQuizzes');

    if (attempts.length === 0) {
        recentContainer.innerHTML = '<p style="color: var(--text-secondary);">No quiz attempts yet. Start taking quizzes to see your history!</p>';
        return;
    }

    const recent = attempts.slice(-10).reverse();
    
    recentContainer.innerHTML = recent.map(attempt => {
        const date = new Date(attempt.timestamp);
        const dateStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        return `
            <div class="quiz-item">
                <div class="quiz-item-info">
                    <h4>${attempt.subject}</h4>
                    <p class="quiz-item-date">${dateStr} • ${attempt.difficulty}</p>
                </div>
                <div class="quiz-item-score">
                    <div class="quiz-item-score-value">${attempt.score}%</div>
                    <div class="quiz-item-score-label">${attempt.xpEarned} XP</div>
                </div>
            </div>
        `;
    }).join('');
}

function logout() {
    Storage.logout();
    window.location.href = 'login.html';
}
