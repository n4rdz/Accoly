// ============================================
// AUTHENTICATION LOGIC
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is already logged in
    const currentUser = Storage.getCurrentUser();
    if (currentUser && !window.location.pathname.includes('login') && !window.location.pathname.includes('signup')) {
        // Logged in, allow access
    } else if (currentUser && (window.location.pathname.includes('login') || window.location.pathname.includes('signup'))) {
        // Logged in but on auth page, redirect to dashboard
        window.location.href = 'dashboard.html';
    }

    // Handle login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }

    // Handle signup form
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleSignup();
        });
    }
});

function handleLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorDiv = document.getElementById('error-message');

    // Find user
    const user = Storage.getUserByEmail(email);
    
    if (!user) {
        showError(errorDiv, 'User not found. Please check your email.');
        return;
    }

    // Verify password
    if (user.password !== password) {
        showError(errorDiv, 'Incorrect password. Please try again.');
        return;
    }

    // Login successful
    Storage.setCurrentUser(user);
    window.location.href = 'dashboard.html';
}

function handleSignup() {
    const fullName = document.getElementById('fullName').value;
    const studentId = document.getElementById('studentId').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const errorDiv = document.getElementById('error-message');

    // Validation
    if (!fullName || !studentId || !email || !password) {
        showError(errorDiv, 'All fields are required.');
        return;
    }

    if (password.length < 6) {
        showError(errorDiv, 'Password must be at least 6 characters.');
        return;
    }

    if (password !== confirmPassword) {
        showError(errorDiv, 'Passwords do not match.');
        return;
    }

    // Check if user already exists
    if (Storage.getUserByEmail(email)) {
        showError(errorDiv, 'Email already registered. Please login instead.');
        return;
    }

    // Create new user
    const newUser = {
        id: Date.now().toString(),
        fullName,
        studentId,
        email,
        password, // Note: In production, this should be hashed!
        createdAt: new Date().toISOString()
    };

    Storage.saveUser(newUser);
    Storage.setCurrentUser(newUser);
    
    // Initialize user stats
    let stats = JSON.parse(localStorage.getItem('userStats') || '{}');
    stats[newUser.id] = {
        totalQuizzes: 0,
        totalXP: 0,
        accuracyPercentage: 0,
        currentStreak: 0,
        bestScore: 0,
        level: 1,
        lastAttemptDate: null
    };
    localStorage.setItem('userStats', JSON.stringify(stats));

    // Redirect to dashboard
    window.location.href = 'dashboard.html';
}

function showError(errorDiv, message) {
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 5000);
}
