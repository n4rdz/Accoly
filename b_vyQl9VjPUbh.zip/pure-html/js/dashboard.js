// ============================================
// DASHBOARD LOGIC
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    const user = Storage.getCurrentUser();
    if (!user) {
        window.location.href = 'login.html';
        return;
    }

    // Initialize dashboard
    initDashboard();
});

function initDashboard() {
    const user = Storage.getCurrentUser();
    const stats = Storage.getUserStats(user.id);

    // Set user info
    document.getElementById('userName').textContent = user.fullName;
    document.getElementById('userAvatar').textContent = user.fullName
        .split(' ')
        .map(n => n[0])
        .join('')
        .toUpperCase();

    // Welcome message
    const hour = new Date().getHours();
    let greeting = 'Good Morning';
    if (hour >= 12 && hour < 18) greeting = 'Good Afternoon';
    if (hour >= 18) greeting = 'Good Evening';
    
    document.getElementById('welcomeMessage').textContent = `${greeting}, ${user.fullName.split(' ')[0]}!`;
    document.getElementById('streakMessage').textContent = `You have a ${stats.currentStreak || 0} day study streak. Keep it up! 🔥`;

    // Update stats
    const levelName = Storage.getLevelName(stats.level);
    document.getElementById('overallProgress').textContent = stats.accuracyPercentage + '%';
    document.getElementById('quizzesCompleted').textContent = stats.totalQuizzes;
    document.getElementById('studyHours').textContent = Math.round(stats.totalQuizzes * 0.5) + 'h';
    document.getElementById('currentLevel').textContent = levelName;

    // Load recent activity
    loadRecentActivity(user.id);
}

function loadRecentActivity(userId) {
    const attempts = Storage.getQuizAttempts(userId);
    const recentList = document.getElementById('recentActivityList');
    
    if (attempts.length === 0) {
        recentList.innerHTML = '<p style="color: var(--text-secondary);">No recent activity. Start by taking a quiz!</p>';
        return;
    }

    // Get 5 most recent
    const recent = attempts.slice(-5).reverse();
    
    recentList.innerHTML = recent.map(attempt => `
        <div class="activity-item">
            <div class="activity-text">
                <h4>Completed ${attempt.subject} Quiz</h4>
                <p class="activity-time">${new Date(attempt.timestamp).toLocaleDateString()}</p>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 1.5rem; font-weight: 700; color: var(--primary);">${attempt.score}%</div>
            </div>
        </div>
    `).join('');
}

function logout() {
    Storage.logout();
    window.location.href = 'login.html';
}
