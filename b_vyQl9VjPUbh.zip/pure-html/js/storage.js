// ============================================
// LOCAL STORAGE MANAGEMENT
// ============================================

const Storage = {
    // Users
    saveUser: function(user) {
        let users = JSON.parse(localStorage.getItem('users') || '[]');
        users.push(user);
        localStorage.setItem('users', JSON.stringify(users));
    },

    getUserByEmail: function(email) {
        let users = JSON.parse(localStorage.getItem('users') || '[]');
        return users.find(u => u.email === email);
    },

    getCurrentUser: function() {
        return JSON.parse(localStorage.getItem('currentUser') || 'null');
    },

    setCurrentUser: function(user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
    },

    logout: function() {
        localStorage.removeItem('currentUser');
    },

    // Quiz Data
    saveQuizAttempt: function(attempt) {
        let attempts = JSON.parse(localStorage.getItem('quizAttempts') || '[]');
        attempt.id = Date.now().toString();
        attempt.timestamp = new Date().toISOString();
        attempts.push(attempt);
        localStorage.setItem('quizAttempts', JSON.stringify(attempts));
        
        // Update user stats
        this.updateUserStats(attempt);
        return attempt;
    },

    getQuizAttempts: function(userId = null) {
        let attempts = JSON.parse(localStorage.getItem('quizAttempts') || '[]');
        if (userId) {
            return attempts.filter(a => a.userId === userId);
        }
        return attempts;
    },

    // Notes
    saveNote: function(note) {
        let notes = JSON.parse(localStorage.getItem('notes') || '[]');
        note.id = note.id || Date.now().toString();
        note.createdAt = note.createdAt || new Date().toISOString();
        note.updatedAt = new Date().toISOString();
        
        const index = notes.findIndex(n => n.id === note.id);
        if (index > -1) {
            notes[index] = note;
        } else {
            notes.push(note);
        }
        localStorage.setItem('notes', JSON.stringify(notes));
        return note;
    },

    getNotes: function(userId = null) {
        let notes = JSON.parse(localStorage.getItem('notes') || '[]');
        if (userId) {
            return notes.filter(n => n.userId === userId);
        }
        return notes;
    },

    deleteNote: function(noteId) {
        let notes = JSON.parse(localStorage.getItem('notes') || '[]');
        notes = notes.filter(n => n.id !== noteId);
        localStorage.setItem('notes', JSON.stringify(notes));
    },

    // User Stats
    updateUserStats: function(quizAttempt) {
        const user = this.getCurrentUser();
        if (!user) return;

        let stats = JSON.parse(localStorage.getItem('userStats') || '{}');
        if (!stats[user.id]) {
            stats[user.id] = {
                totalQuizzes: 0,
                totalXP: 0,
                accuracyPercentage: 0,
                currentStreak: 0,
                bestScore: 0,
                level: 1,
                lastAttemptDate: null
            };
        }

        const userStats = stats[user.id];
        
        // Calculate XP
        const xpEarned = this.calculateXP(quizAttempt);
        userStats.totalXP += xpEarned;
        userStats.totalQuizzes += 1;
        
        // Update accuracy
        const allAttempts = this.getQuizAttempts(user.id);
        const totalCorrect = allAttempts.reduce((sum, a) => sum + a.correctAnswers, 0);
        const totalQuestions = allAttempts.reduce((sum, a) => sum + a.totalQuestions, 0);
        userStats.accuracyPercentage = totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0;
        
        // Update best score
        const score = quizAttempt.score;
        if (score > userStats.bestScore) {
            userStats.bestScore = score;
        }

        // Update level
        userStats.level = this.calculateLevel(userStats.totalXP);
        
        // Update streak
        userStats.lastAttemptDate = new Date().toDateString();
        
        localStorage.setItem('userStats', JSON.stringify(stats));
    },

    getUserStats: function(userId) {
        let stats = JSON.parse(localStorage.getItem('userStats') || '{}');
        return stats[userId] || {
            totalQuizzes: 0,
            totalXP: 0,
            accuracyPercentage: 0,
            currentStreak: 0,
            bestScore: 0,
            level: 1,
            lastAttemptDate: null
        };
    },

    calculateXP: function(quizAttempt) {
        let baseXP = 0;
        
        // Base XP by difficulty
        if (quizAttempt.difficulty === 'Easy') baseXP = 50;
        if (quizAttempt.difficulty === 'Intermediate') baseXP = 100;
        if (quizAttempt.difficulty === 'Hard') baseXP = 200;

        // Bonus for accuracy
        const accuracy = (quizAttempt.correctAnswers / quizAttempt.totalQuestions) * 100;
        if (accuracy === 100) baseXP += 150;
        else if (accuracy >= 90) baseXP += 75;
        else if (accuracy >= 80) baseXP += 25;
        else if (accuracy < 70) return 0; // No XP for failing

        return Math.round(baseXP);
    },

    calculateLevel: function(totalXP) {
        if (totalXP < 500) return 1;
        if (totalXP < 1500) return 2;
        if (totalXP < 3500) return 3;
        if (totalXP < 7000) return 4;
        return 5;
    },

    getLevelName: function(level) {
        const names = {
            1: 'Beginner Accountant',
            2: 'Junior Analyst',
            3: 'Senior Reviewer',
            4: 'Audit Specialist',
            5: 'CPA Elite'
        };
        return names[level] || 'Student';
    }
};
