// ============================================
// QUIZ ENGINE - FULL FUNCTIONALITY
// ============================================

let currentQuizModule = null;
let currentQuestions = [];
let currentQuestionIndex = 0;
let selectedAnswers = {};
let quizStartTime = null;
let quizTimerInterval = null;
let timeLimit = 30 * 60; // 30 minutes in seconds
let remainingTime = timeLimit;

document.addEventListener('DOMContentLoaded', function() {
    const user = Storage.getCurrentUser();
    if (!user) {
        window.location.href = 'login.html';
        return;
    }

    initQuizCenter();
});

function initQuizCenter() {
    loadQuizModules();
}

function loadQuizModules() {
    const modulesContainer = document.getElementById('quizModules');
    
    modulesContainer.innerHTML = QUIZ_MODULES.map(module => `
        <div class="quiz-module">
            <div class="quiz-module-header" style="background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%);">
                <div class="quiz-module-title">
                    <h3>${module.name}</h3>
                    <p>10 Questions • ${module.difficulty}</p>
                </div>
                <div class="difficulty-badge">${module.difficulty}</div>
            </div>
            <div class="quiz-module-body">
                <div class="module-stat">
                    <span class="module-stat-label">Questions</span>
                    <span class="module-stat-value">10</span>
                </div>
                <div class="module-stat">
                    <span class="module-stat-label">Time Limit</span>
                    <span class="module-stat-value">30 min</span>
                </div>
                <div class="module-stat">
                    <span class="module-stat-label">Difficulty</span>
                    <span class="module-stat-value">${module.difficulty}</span>
                </div>
                <button onclick="startQuiz(${module.id})" class="btn btn-primary">
                    Start Quiz
                </button>
            </div>
        </div>
    `).join('');
}

function filterQuizzes(difficulty) {
    // Update button states
    document.querySelectorAll('.difficulty-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    const modulesContainer = document.getElementById('quizModules');
    
    if (difficulty === 'All') {
        loadQuizModules();
    } else {
        const filtered = QUIZ_MODULES.filter(m => m.difficulty === difficulty);
        modulesContainer.innerHTML = filtered.map(module => `
            <div class="quiz-module">
                <div class="quiz-module-header" style="background: linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%);">
                    <div class="quiz-module-title">
                        <h3>${module.name}</h3>
                        <p>10 Questions • ${module.difficulty}</p>
                    </div>
                    <div class="difficulty-badge">${module.difficulty}</div>
                </div>
                <div class="quiz-module-body">
                    <div class="module-stat">
                        <span class="module-stat-label">Questions</span>
                        <span class="module-stat-value">10</span>
                    </div>
                    <div class="module-stat">
                        <span class="module-stat-label">Time Limit</span>
                        <span class="module-stat-value">30 min</span>
                    </div>
                    <div class="module-stat">
                        <span class="module-stat-label">Difficulty</span>
                        <span class="module-stat-value">${module.difficulty}</span>
                    </div>
                    <button onclick="startQuiz(${module.id})" class="btn btn-primary">
                        Start Quiz
                    </button>
                </div>
            </div>
        `).join('');
    }
}

function startQuiz(moduleId) {
    currentQuizModule = QUIZ_MODULES.find(m => m.id === moduleId);
    currentQuestions = QUIZ_QUESTIONS[moduleId];
    
    // Shuffle questions
    currentQuestions = currentQuestions.sort(() => Math.random() - 0.5);
    
    currentQuestionIndex = 0;
    selectedAnswers = {};
    quizStartTime = Date.now();
    remainingTime = timeLimit;

    // Show quiz interface
    document.getElementById('quizSelection').style.display = 'none';
    document.getElementById('quizTaking').style.display = 'block';
    document.getElementById('quizResults').style.display = 'none';

    // Load first question
    loadQuestion();

    // Start timer
    startTimer();
}

function startTimer() {
    quizTimerInterval = setInterval(() => {
        remainingTime--;
        updateTimerDisplay();

        if (remainingTime <= 0) {
            clearInterval(quizTimerInterval);
            submitQuiz();
        }
    }, 1000);
}

function updateTimerDisplay() {
    const minutes = Math.floor(remainingTime / 60);
    const seconds = remainingTime % 60;
    const timerDisplay = document.getElementById('timerDisplay');
    timerDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;

    // Change color based on time remaining
    if (remainingTime <= 300) { // 5 minutes
        timerDisplay.parentElement.classList.add('danger');
        timerDisplay.parentElement.classList.remove('warning');
    } else if (remainingTime <= 600) { // 10 minutes
        timerDisplay.parentElement.classList.add('warning');
        timerDisplay.parentElement.classList.remove('danger');
    }
}

function loadQuestion() {
    const question = currentQuestions[currentQuestionIndex];
    
    document.getElementById('quizTitle').textContent = currentQuizModule.name;
    document.getElementById('quizProgress').textContent = `Question ${currentQuestionIndex + 1} of ${currentQuestions.length}`;
    document.getElementById('questionText').textContent = question.question;

    const optionsContainer = document.getElementById('optionsContainer');
    optionsContainer.innerHTML = question.options.map((option, index) => `
        <button 
            class="option-btn ${selectedAnswers[currentQuestionIndex] === index ? 'selected' : ''}"
            onclick="selectAnswer(${index})"
        >
            ${option}
        </button>
    `).join('');

    // Update question navigator
    updateQuestionNavigator();

    // Update submit button text
    const submitBtn = document.getElementById('submitBtn');
    if (currentQuestionIndex === currentQuestions.length - 1) {
        submitBtn.textContent = 'Submit Quiz';
    } else {
        submitBtn.textContent = 'Submit Quiz';
    }
}

function selectAnswer(index) {
    selectedAnswers[currentQuestionIndex] = index;
    
    // Reload question to update button states
    const optionsContainer = document.getElementById('optionsContainer');
    const question = currentQuestions[currentQuestionIndex];
    
    optionsContainer.innerHTML = question.options.map((option, optionIndex) => `
        <button 
            class="option-btn ${selectedAnswers[currentQuestionIndex] === optionIndex ? 'selected' : ''}"
            onclick="selectAnswer(${optionIndex})"
        >
            ${option}
        </button>
    `).join('');
}

function updateQuestionNavigator() {
    const navigatorContainer = document.getElementById('questionNavigator');
    navigatorContainer.innerHTML = '';

    for (let i = 0; i < currentQuestions.length; i++) {
        const btn = document.createElement('button');
        btn.className = 'nav-button';
        btn.textContent = i + 1;
        
        if (i === currentQuestionIndex) {
            btn.classList.add('current');
        } else if (selectedAnswers[i] !== undefined) {
            btn.classList.add('answered');
        }

        btn.onclick = () => goToQuestion(i);
        navigatorContainer.appendChild(btn);
    }
}

function goToQuestion(index) {
    currentQuestionIndex = index;
    loadQuestion();
}

function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        loadQuestion();
    }
}

function nextQuestion() {
    if (currentQuestionIndex < currentQuestions.length - 1) {
        currentQuestionIndex++;
        loadQuestion();
    }
}

function exitQuiz() {
    if (confirm('Are you sure you want to exit? Your progress will be lost.')) {
        clearInterval(quizTimerInterval);
        document.getElementById('quizSelection').style.display = 'block';
        document.getElementById('quizTaking').style.display = 'none';
        document.getElementById('quizResults').style.display = 'none';
        loadQuizModules();
    }
}

function submitQuiz() {
    clearInterval(quizTimerInterval);

    // Calculate score
    let correctCount = 0;
    for (let i = 0; i < currentQuestions.length; i++) {
        if (selectedAnswers[i] === currentQuestions[i].correct) {
            correctCount++;
        }
    }

    const score = Math.round((correctCount / currentQuestions.length) * 100);
    const timeTaken = Math.floor((Date.now() - quizStartTime) / 1000);
    const xpEarned = Storage.calculateXP({
        difficulty: currentQuizModule.difficulty,
        correctAnswers: correctCount,
        totalQuestions: currentQuestions.length,
        score: score
    });

    // Save attempt
    const user = Storage.getCurrentUser();
    const attempt = {
        userId: user.id,
        subject: currentQuizModule.subject,
        difficulty: currentQuizModule.difficulty,
        score: score,
        correctAnswers: correctCount,
        totalQuestions: currentQuestions.length,
        timeTaken: timeTaken,
        xpEarned: xpEarned
    };
    Storage.saveQuizAttempt(attempt);

    // Show results
    showResults(score, correctCount, timeTaken, xpEarned);
}

function showResults(score, correctCount, timeTaken, xpEarned) {
    document.getElementById('quizSelection').style.display = 'none';
    document.getElementById('quizTaking').style.display = 'none';
    document.getElementById('quizResults').style.display = 'block';

    // Calculate grade
    let grade = 'F';
    let gradeColor = '#EF4444';
    if (score >= 90) { grade = 'A'; gradeColor = '#10B981'; }
    else if (score >= 80) { grade = 'B'; gradeColor = '#3B82F6'; }
    else if (score >= 70) { grade = 'C'; gradeColor = '#F59E0B'; }

    document.getElementById('gradeDisplay').textContent = grade;
    document.getElementById('gradeDisplay').parentElement.style.background = gradeColor;

    const minutes = Math.floor(timeTaken / 60);
    const seconds = timeTaken % 60;

    document.getElementById('finalScore').textContent = score + '%';
    document.getElementById('correctCount').textContent = `${correctCount}/${currentQuestions.length}`;
    document.getElementById('timeTaken').textContent = `${minutes}m ${seconds}s`;
    document.getElementById('xpEarned').textContent = xpEarned + ' XP';

    // Score message
    const scoreMessage = document.getElementById('scoreMessage');
    if (score >= 90) scoreMessage.textContent = 'Excellent performance! Keep it up! 🌟';
    else if (score >= 80) scoreMessage.textContent = 'Great job! You\'re doing well! 👏';
    else if (score >= 70) scoreMessage.textContent = 'Good effort! Keep practicing! 💪';
    else scoreMessage.textContent = 'Keep studying and try again! 📚';
}

function retakeQuiz() {
    startQuiz(currentQuizModule.id);
}

function backToQuizList() {
    document.getElementById('quizSelection').style.display = 'block';
    document.getElementById('quizTaking').style.display = 'none';
    document.getElementById('quizResults').style.display = 'none';
    loadQuizModules();
}

function logout() {
    Storage.logout();
    window.location.href = 'login.html';
}
